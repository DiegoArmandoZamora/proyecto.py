from django.shortcuts import render, redirect

from django.contrib import messages

from .forms import LeadForm

def cotizar(request):
    if request.method == 'POST':
        form = LeadForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '¡Cotización enviada con éxito! Te contactaremos pronto.')
            return redirect('cotizar')       
    else:
        form = LeadForm()
    
    return render(request, 'leads/cotizar.html', {'form': form})

def home(request):
    return render(request, 'home.html')
# Create your views here.
